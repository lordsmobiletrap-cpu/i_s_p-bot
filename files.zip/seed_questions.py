"""
Скрипт для заполнения банка вопросов IELTS Speaking Part 2.

Запуск:
    python seed_questions.py

Повторный запуск безопасен — дубликаты не добавляются.
Переменная окружения DB_PATH задаёт путь к БД (default: bot.db).
"""

import asyncio
from os import getenv

import aiosqlite
from dotenv import load_dotenv

load_dotenv()
DB_PATH = getenv("DB_PATH", "bot.db")

# ---------------------------------------------------------------------------
# Банк вопросов
# ---------------------------------------------------------------------------

QUESTIONS = [
    """Title: A memorable journey
You should say:
- where you went
- who you went with
- what you did there
And explain why this journey was so memorable.""",

    """Title: A person who has had a great influence on you
You should say:
- who this person is
- how long you have known them
- what they have done for you
And explain why they have been so influential in your life.""",

    """Title: A book you have recently read
You should say:
- what the book is about
- why you chose to read it
- what you found most interesting about it
And explain whether you would recommend it to others.""",

    """Title: A time when you helped someone
You should say:
- who you helped
- what the situation was
- how you helped them
And explain how you felt about helping this person.""",

    """Title: A skill you would like to learn
You should say:
- what the skill is
- why you want to learn it
- how you plan to learn it
And explain how this skill would benefit your life.""",

    """Title: A place in your country you would recommend to a visitor
You should say:
- where this place is
- what you can do or see there
- when you last visited it
And explain why you think visitors should go there.""",

    """Title: An important decision you have made
You should say:
- what the decision was
- when you made it
- how long it took you to decide
And explain how this decision has affected your life.""",

    """Title: A piece of technology you find useful
You should say:
- what it is
- how long you have had it
- how often you use it
And explain why you find it so useful.""",

    """Title: A childhood memory you have
You should say:
- what the memory is about
- how old you were at the time
- who was with you
And explain why this memory has stayed with you.""",

    """Title: A sport or physical activity you enjoy
You should say:
- what the activity is
- how often you do it
- where you do it
And explain why you enjoy this activity.""",

    """Title: A time when you were very busy
You should say:
- when this was
- what you were doing
- how you managed your time
And explain how you felt during this busy period.""",

    """Title: A film that made a strong impression on you
You should say:
- what the film was about
- when and where you watched it
- who you watched it with
And explain why this film made such a strong impression on you.""",

    """Title: An occasion when you received excellent service
You should say:
- when and where it happened
- what service you received
- who provided the service
And explain why you thought the service was so good.""",

    """Title: A time when you learned something from a mistake
You should say:
- what the mistake was
- when it happened
- what you did after you realised your mistake
And explain what you learned from this experience.""",

    """Title: A traditional food from your country
You should say:
- what the food is
- how it is made
- on what occasions people eat it
And explain why this food is important to your culture.""",

    """Title: An ambition you have had for a long time
You should say:
- what the ambition is
- how long you have had this ambition
- what you have done to achieve it so far
And explain why this ambition is important to you.""",

    """Title: A time when you had to speak in public
You should say:
- when and where this happened
- what you spoke about
- how well prepared you were
And explain how you felt before and after the experience.""",

    """Title: A gift you gave that was well received
You should say:
- what the gift was
- who you gave it to
- what the occasion was
And explain why you chose that particular gift.""",

    """Title: A time when you visited a museum or art gallery
You should say:
- which museum or gallery you visited
- what you saw there
- who you went with
And explain what you found most interesting about the visit.""",

    """Title: A job you would love to have in the future
You should say:
- what the job is
- what skills or qualifications you would need
- why you are interested in this job
And explain how you plan to pursue this career.""",
]


# ---------------------------------------------------------------------------
# Вставка в БД
# ---------------------------------------------------------------------------

async def seed() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        # Получаем уже существующие вопросы, чтобы не дублировать
        async with db.execute("SELECT body FROM questions") as cursor:
            existing = {row[0] for row in await cursor.fetchall()}

        new_questions = [q.strip() for q in QUESTIONS if q.strip() not in existing]

        if not new_questions:
            print("✅ All questions already exist in the database. Nothing to add.")
            return

        await db.executemany(
            "INSERT INTO questions (body) VALUES (?)",
            [(q,) for q in new_questions]
        )
        await db.commit()
        print(f"✅ Added {len(new_questions)} new question(s). "
              f"Skipped {len(QUESTIONS) - len(new_questions)} duplicate(s).")


if __name__ == "__main__":
    asyncio.run(seed())
